import { jsPDF } from "jspdf";

export default async function handler(req, res) {
  const { data } = req.body;
  const doc = new jsPDF();
  doc.text("Steuerdaten Schweiz – Export", 10, 10);
  doc.text(`Jahr: ${data.jahr}`, 10, 20);
  doc.text(`Bruttolohn: CHF ${data.bruttolohn}`, 10, 30);
  const pdf = doc.output("arraybuffer");
  res.setHeader("Content-Type", "application/pdf");
  res.setHeader("Content-Disposition", "attachment; filename=steuerdaten.pdf");
  res.status(200).send(Buffer.from(pdf));
}
