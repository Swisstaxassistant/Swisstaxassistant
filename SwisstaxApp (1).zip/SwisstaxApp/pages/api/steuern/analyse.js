export const config = { api: { bodyParser: false } };

export default async function handler(req, res) {
  const summary = "Bruttolohn: 83'500 CHF erkannt.";
  const data = { bruttolohn: 83500, jahr: 2024 };
  res.status(200).json({ summary, data });
}
