export default async function handler(req, res) {
  const { message } = req.body;
  const reply = `Danke für deine Frage zur Steuer. Du hast gefragt: "${message}".`;
  res.status(200).json({ reply });
}
