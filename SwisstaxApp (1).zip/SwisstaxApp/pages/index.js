export default function Home() {
  return (
    <main>
      <h1>Willkommen bei SwissTaxAssistant</h1>
      <p>Lade deinen Lohnausweis hoch und starte die automatische Steuerberechnung.</p>
    </main>
  );
}
